drop table ci_rt_mapping;

